import kafka.security.auth.LdapGroupsMapping;

import java.io.FileReader;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

public class Test {
    public static void main(String[] args) throws Exception {
        Properties props = new Properties();
        props.load(new FileReader(ClassLoader.getSystemResource("server.properties").getFile()));

        Enumeration<?> enumeration = props.propertyNames();
        while (enumeration.hasMoreElements()) {

            Object key = enumeration.nextElement();
            System.out.println(key + ": " + props.getProperty(key.toString()));
        }

        LdapGroupsMapping lgm = new LdapGroupsMapping();
        lgm.setConf(props);
        long start, end;
        int i = 0;
        lgm.getGroups("user02");
        while (true) {
            start = new Date().getTime();
            List<String> groups = lgm.getGroups("user01");
            end = new Date().getTime();
            System.out.println("Stop " + i + " : result -> " + groups + ", taken time : " + (end - start));
            Thread.sleep(500);
        }


    }
}
