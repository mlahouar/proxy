## TODO : 

* Unit Tests
* CI/CD pipelines
* Search on multiple domains ?
* ??


    ldap.authorizer.url=ldap://ldap-server:port/dc=ml,dc=com
    ldap.authorizer.ssl=false
    ldap.authorizer.bind.user=cn=Manager,dc=ml,dc=com
    ldap.authorizer.bind.password.file=/etc/security/passwords/ldap_ro_user_password.txt
    ldap.authorizer.search.filter.user=(krbPrincipalName={0}*)
    ldap.authorizer.search.filter.group=(objectClass=posixGroup)
    ldap.authorizer.search.attr.member=memberUid
    ldap.authorizer.refresh.interval.ms=3000

